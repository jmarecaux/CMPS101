README.txt

Jules Marecaux
jrmareca
1574177

PA2

Files included:

Lex.c			- the main.c script for reading sorting, printing, and writing from 
				  the in file to the out file, based heavily on my java one from 
				  the last PA and from Tantalo's FILEIO.c

List.c			- the .c implementation of the same List as our last PA in java. 
				  Written by me. It was easy for me to take my .java file and simply 
				  translate it.

List.h			- the .h file, based strongly on the assignemnt functions given for 
				  the header file of List. every function is included in the .h and
				  implemented in the .c. 

README.txt		- the table of contents for the PA2 assignment. also includes notes 
				  for the grader at the bottom

Makefile		- pulled from the webpage under PA2/Makefile and not edited.

ListClient.c	- pulled from the webpage under PA2/ListClient.c and not altered.

----------------------------------------------------------------------

Notes:

A lot of resources have been given to us through the website and help through piazza
and I was able to complete the assignment with these resources. I like the way this
was done, as I learned a lot writing it out with these resources.


